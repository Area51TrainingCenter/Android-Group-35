package pe.area51.socialapp.screens.login.viewmodel;

/**
 * Created by segundo on 14/09/17.
 */

public class SignUpFragViewModel {
}
