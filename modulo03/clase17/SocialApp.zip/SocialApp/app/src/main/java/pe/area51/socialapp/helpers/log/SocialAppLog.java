package pe.area51.socialapp.helpers.log;

import android.util.Log;

/**
 * Created by segundo on 7/09/17.
 */

public class SocialAppLog {

    public static void getMessage(String message) {
        Log.d("SocialApp", message);
    }

}
